package RUCafe;


public class MenuItem {
    private String menuItem;
    private String number;

    public MenuItem(String menuItem){

        this.menuItem = menuItem;

    }

    public MenuItem() {

    }

    public String getItem(){
        return this.menuItem;
    }
    public void setNumber(String number){
        this.number = number;
    }



    public void itemPrice(){

    }

}
