package RUCafe;

public interface Customizable{
    boolean add(Object obj);
    boolean remove(Object obj);
}