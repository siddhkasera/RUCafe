package RUCafeApp;

import javafx.scene.input.MouseEvent;

/**
 * This class processes the GUI from the payroll_processing_gui.fxml in order to
 * manage different operations on GUI
 *
 * @author Siddhi Kasera, Sonal Madhok
 **/
public class ControllerCurrentOrder {

    public void removeItem(MouseEvent mouseEvent) {
    }

    public void placeOrder(MouseEvent mouseEvent) {
    }
}