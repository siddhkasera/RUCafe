package RUCafeApp;

import javafx.fxml.FXML;
import javafx.scene.input.MouseEvent;

import java.awt.*;

/**
 * This class processes the GUI from the payroll_processing_gui.fxml in order to
 * manage different operations on GUI
 *
 * @author Siddhi Kasera, Sonal Madhok
 **/
public class ControllerMainMenu {


    public void customerOrderPage(MouseEvent mouseEvent) {
        //open fxml
    }

    public void storeOrdersPage(MouseEvent mouseEvent) {
    }

    public void orderCoffeePage(MouseEvent mouseEvent) {
    }

    public void orderDonutPage(MouseEvent mouseEvent) {
    }
}