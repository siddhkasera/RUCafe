package RUCafeApp;

import javafx.scene.input.MouseEvent;

/**
 * This class processes the GUI from the payroll_processing_gui.fxml in order to
 * manage different operations on GUI
 *
 * @author Siddhi Kasera, Sonal Madhok
 **/
public class ControllerStoreOrders {


    public void cancelOrder(MouseEvent mouseEvent) {
    }

    public void exportOrders(MouseEvent mouseEvent) {
    }
}